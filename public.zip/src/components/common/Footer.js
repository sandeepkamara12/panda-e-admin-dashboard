import React from 'react'

const Footer = () => {
  return (
    <footer className="app-footer fixed bottom-0 bg-orange-900 left-0 right-0">
    <p>© 2025 My Application. All rights reserved.</p>
  </footer>
  )
}

export default Footer
