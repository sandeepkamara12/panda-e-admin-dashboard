import React from 'react'

const About = () => {
  return (
    <div className=''>
      welcome to About
    </div>
  )
}

export default About
