import React from 'react'
import ActivityNotification from '../components/ActivityNotification';
const Dashboard = () => {
  return (
    <div className='grid grid-rows-1 grid-cols-4 space-x-8 mb-7'>
        <div className='flex flex-wrap space-x-5 p-6 rounded-md bg-black shadow-dashboard bg-gradient-to-b from-purple-400 to-purple-600'>
            <div className="card-wrapper flex flex-wrap justify-between w-full">
              <div className="card-value">
                <h3 className='text-[22px] font-bold mb-1'>136,758K</h3>
                <p className='capitalize text-sm font-medium'>impression</p>
              </div>
              <div className="card-dropdown">
                <ActivityNotification />
              </div>
            </div>
        </div>
        <div className='flex flex-wrap space-x-5 p-6 rounded-md bg-black shadow-dashboard bg-gradient-to-b from-green-400 to-green-600'>
            <div className="card-wrapper flex flex-wrap justify-between w-full">
              <div className="card-value">
                <h3 className='text-[22px] font-bold mb-1'>136,758K</h3>
                <p className='capitalize text-sm font-medium'>engagements</p>
              </div>
              <div className="card-dropdown">
                <ActivityNotification />
              </div>
            </div>
        </div>
        <div className='flex flex-wrap space-x-5 p-6 rounded-md bg-black shadow-dashboard bg-gradient-to-b from-blue-400 to-blue-600'>
            <div className="card-wrapper flex flex-wrap justify-between w-full">
              <div className="card-value">
                <h3 className='text-[22px] font-bold mb-1'>136,758K</h3>
                <p className='capitalize text-sm font-medium'>conversions</p>
              </div>
              <div className="card-dropdown">
                <ActivityNotification />
              </div>
            </div>
        </div>
        <div className='flex flex-wrap space-x-5 p-6 rounded-md bg-black shadow-dashboard bg-gradient-to-b from-red-400 to-red-600'>
            <div className="card-wrapper flex flex-wrap justify-between w-full">
              <div className="card-value">
                <h3 className='text-[22px] font-bold mb-1'>136,758K</h3>
                <p className='capitalize text-sm font-medium'>bounce rate</p>
              </div>
              <div className="card-dropdown">
                <ActivityNotification />
              </div>
            </div>
        </div>
    </div>
  )
}

export default Dashboard
